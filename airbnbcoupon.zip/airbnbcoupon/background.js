var act = 0;
var data = [];
var current_process = 0;

chrome.browserAction.onClicked.addListener(function(tab) 
{
	//chrome.tabs.executeScript(tab.id, {file: 'js/load_script.js'});
	chrome.tabs.update({
		url: tab.url
	});
	
	act = 1;
});

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
	if(changeInfo.status == "complete") {
		chrome.tabs.executeScript(tab.id, {file: 'js/load_script.js'});
		console.log("Load Script : " + act)
                
		
	}
})

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) 
{
	if (request.act == "check_act")
	{
		sendResponse({
			act: act
		});	
	}
	
	if (request.act == "send_data")
	{
		data = request.dta
		act = 2;

		chrome.tabs.update({
			url: data[current_process]
		});
		
		current_process++;
	}
	
	if (request.act == "send_data_1")
	{
		act = 2;
		chrome.tabs.update({
			url: data[current_process]
		});
		
		current_process++;
	}
})


