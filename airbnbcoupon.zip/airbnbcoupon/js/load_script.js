timeout();
function timeout() {
    fetch("https://it.airbnb.com/api/v2/users/me?currency=USD&key=d306zoyjsyarp7ifhu67rjxn52tv0t20&locale=it", {
  "headers": {
    "accept": "application/json, text/javascript, */*; q=0.01",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "content-type": "application/json; charset=utf-8",
    "device-memory": "4",
    "dpr": "1",
    "ect": "4g",
    "sec-ch-ua": "\"Google Chrome\";v=\"105\", \"Not)A;Brand\";v=\"8\", \"Chromium\";v=\"105\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "viewport-width": "448",
    "x-airbnb-supports-airlock-v2": "true",
    "x-csrf-without-token": "1",
    "x-requested-with": "XMLHttpRequest"
  },
  "referrer": "https://it.airbnb.com/account-settings/personal-info",
  "referrerPolicy": "strict-origin-when-cross-origin",
  "body": "{\"email\":\"kontakmanusia.milenial@gmail.com\",\"_format\":\"for_account_settings_personal_info\"}",
  "method": "PUT",
  "mode": "cors",
  "credentials": "include"
});
}